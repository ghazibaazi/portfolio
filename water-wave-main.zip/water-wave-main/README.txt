This is a fullstack app:
The stack used is: 
**FrontEnd**
HTML, CSS, JavaScript, Bootstrap

**Backend**
NodeJS, ExpressJS, Microsoft SQL Server
